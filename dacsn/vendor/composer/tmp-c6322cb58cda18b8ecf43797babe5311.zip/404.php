<?php

/*

  type: layout
  content_type: static
  name: Error 404
  position: 11
  description: Error 404

*/

?>
<?php include template_dir() . "header.php"; ?>

<div class="edit main-content" data-layout-container rel="global" field="content">
    <module type="layouts" template="404"/>
</div>

<?php include template_dir() . "footer.php"; ?>
