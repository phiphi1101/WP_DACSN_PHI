<?php

/*

type: layout
content_type: static
name: Contact Us
position: 6
description: Contact Us

*/


?>
<?php include template_dir() . "header.php"; ?>

    <div class="edit main-content" data-layout-container rel="content" field="content">
        <module type="layouts" template="titles/skin-4"/>
        <module type="layouts" template="content/skin-4"/>
    </div>

<?php include template_dir() . "footer.php"; ?>
