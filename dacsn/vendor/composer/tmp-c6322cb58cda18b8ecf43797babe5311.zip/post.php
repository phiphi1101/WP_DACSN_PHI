<?php

include(__DIR__ . DS . 'layouts/blog_inner.php');
