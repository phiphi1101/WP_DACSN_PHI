<?php only_admin_access() ?>


<?php include('slick_options.php'); ?>

    <div class="mw-flex-row m-t-30">
        <div class="mw-flex-col-xs-4 ">
            <h3>Posts Slider Settings</h3>
        </div>
    </div>

<?php include('slick_options_ui.php'); ?>