<?php

/*

  type: layout
  content_type: static
  name: Menu - skin-1
  position: 1
  description: Menu - skin-1
  categories: Menu


*/

?>
<section class="header-background">
    <div class="container">
        <nav class="nav-pills">
            <div class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
                <module type="menu" name="header_menu" id="header_menu" template="navbar" class="d-flex flex-direction-row nav-holder"/>
            </div>
        </nav>
    </div>
</section>




