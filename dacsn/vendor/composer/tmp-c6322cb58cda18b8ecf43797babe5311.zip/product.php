<?php include(__DIR__ . DS . 'layouts/shop_inner.php'); ?>
