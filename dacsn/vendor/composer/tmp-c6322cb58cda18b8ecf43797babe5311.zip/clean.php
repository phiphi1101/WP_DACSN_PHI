<?php

/*

type: layout
content_type: static
name: Clean
position: 1
is_default: true
description: Clean layout

*/


?>
<?php include template_dir() . "header.php"; ?>


<div class="edit main-content" data-layout-container rel="content" field="content">
    <module type="layouts" template="skin-1"/>
</div>

<?php include template_dir() . "footer.php"; ?>
