# Bootstrap 5

A bootstrap 5 based theme Fully responsive, clean and modern design. 

## Features:

* 40 Dynamic Layouts
* Sticky Menu
* Galleries
* Color Schemes 
* Instagram Module
* Paralax Effects
* Testimonials Module
* Reservation Form
* Social Modules
* Pricing Tables
* Pixel Perfect Design
* Blog Posts
* Creative Design
* Fully Responsive
* Cross Browser Support
* Easy to Customize
* SEO Optimized
* Over 2000 icons
* Well Documented
* Free Lifetime Updates
* Custom Support 
* Bootstrap 5 based

![features.jpg](./readme_assets/features.jpg "")
